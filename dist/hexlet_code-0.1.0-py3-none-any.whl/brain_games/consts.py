COUNT_ROUNDS = 3

MATH_SIGNS = ('+', '-', '*')

EVEN_INSTRUCTION = 'Answer "yes" if the number is even, otherwise answer "no".'
CALC_INSTRUCTION = 'What is the result of the expression?'
GCD_INSTRUCTION = 'Find the greatest common divisor of given numbers.'
PRIME_INSTRUCTION = 'Answer "yes" if given number is prime.'\
                    'Otherwise answer "no".'
PROGRESSION_INSTRUCTION = 'What number is missing in the progression?'
