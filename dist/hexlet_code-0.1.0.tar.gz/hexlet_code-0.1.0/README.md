### Hexlet tests and linter status:
[![Actions Status]
GitHub Actions from Hexlet(https://github.com/malina-prog/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)]
                          (https://github.com/malina-prog/python-project-49/actions)

Asciinema (https://asciinema.org/a/4bdgxuBq3YXjESbpCOsb0VJ73)

Code climate (https://codeclimate.com/github/malina-prog/python-project-49)

Description: This project contains five console games.Each game goes up to three correct answers, if you answer incorrectly, you lose.

Minimum requirements:

Installation and startup instructions: